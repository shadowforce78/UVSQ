
Livre : L'avenir de la technologie
Sorti en 2024 c'est un essai

Le livre contient 2 chapitre
"Comprendre pourquoi les machines seront calqué sur les cerveau humains"
Les machines sont faite pour être plus puissante que les cerveau humain a la base, mais pour evoluer, ces machines ne que le cerveau humain pour exemple, le cerveau humain peut apprendre et ressentir sentiments et émotions, ce que les machines ne peuvent pas faire
le cerveau humain essaye aussi d'associer tous ce que l'on ressent a quelque chose de déjà vécut, la compréhension du cerveau est un premier pas pour l'IA

dans le cerveau les neurones marchent entre eux, les machines elles n'ont pas de neurones et utilise donc des câbles optiques

une légende existe: la révolution des robots, ce que ne peux pas arriver, le néocortex du cerveau humain ne peut pas être copier chez les robots, 