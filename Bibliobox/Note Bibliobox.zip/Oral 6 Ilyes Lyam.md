
Livre : Le prénom

**"Le Prénom"** est une comédie de théâtre écrite par Matthieu Delaporte et Alexandre de la Patellière. L'histoire se déroule lors d'un dîner entre amis et révèle des tensions sous-jacentes au fur et à mesure que la soirée avance. 

Le personnage principal, Vincent, annonce qu'il a choisi un prénom très original pour son futur enfant, "Adolphe". Cette révélation déstabilise les autres invités, provoquant un enchaînement de disputes et de révélations. À travers les échanges, on découvre les relations complexes et parfois tendues entre les personnages, entre amour, rancœurs, jalousies et secrets de famille.

Le prénom, banal au départ, devient un prétexte pour explorer des thèmes plus profonds tels que l'amitié, la famille, les préjugés sociaux et les non-dits. L'humour et le dialogue vif sont les piliers de la pièce, qui se termine sur une note de réflexion sur l'impact des choix personnels dans la dynamique des relations humaines.